export const environment = {
  production: true,
  weatherForecast: {
    apiUrl: 'https://samples.openweathermap.org/data/2.5/forecast',
    apiKey: 'b6907d289e10d714a6e88b30761fae22'
  },
  googleMaps: {
    apiUrl: 'https://maps.googleapis.com/maps/api/timezone/json',
    apiKey: 'AIzaSyD7cZtGm_DZca0AqWFvGRxWoQD-AodQhFs'
  }
};
